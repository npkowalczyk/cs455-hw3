
        This package, which includes data for the collection "epa_aqi_general_score" for the region "Colorado" contains the following files:

        NOTE: The actual data file will have been downloaded as a seperate download with the suffix "_raw_data.json" 

        README -- This file

        

        fieldLabels.json -- JSON array including field name label data.
        