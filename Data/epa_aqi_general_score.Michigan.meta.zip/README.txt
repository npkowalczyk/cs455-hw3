
        This package, which includes data for the collection "epa_aqi_general_score" for the region "Michigan" contains the following files:

        NOTE: The actual data file will have been downloaded as a seperate download with the suffix "_raw_data.json" 

        README -- This file

        linkedGeometry.json -- GeoJSON feature file which includes geospatial information about data within data.json.
        Data between the files can be linked using the "GISJOIN" field, which exists at the top level of each entry in both files.

        fieldLabels.json -- JSON array including field name label data.
        